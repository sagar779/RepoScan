function test() {
    console.log("hello");
    // comment
    return true;
}
// 6 lines total including this one
