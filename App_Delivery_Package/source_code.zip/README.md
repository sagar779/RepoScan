# Repository Depth Analyzer

A standalone utility to analyze codebase structure and complexity metrics.

## Features

- **File Inventory**: Scans all files in a directory and collects metadata
- **Complexity Analysis**: Detects inline/internal CSS, JS, AJAX calls, and dynamic resource generation
- **Directory Statistics**: Provides breakdown by directory depth and file extensions
- **Multithreaded Scanning**: Fast processing using concurrent file analysis
- **Excel Reports**: Professional, styled Excel output with multiple tabs
- **.NET Full-Stack Support**: Detects server-side triggers, Razor helpers, and legacy Controls

## Documentation

For a complete explanation of the tool's architecture, pattern matching logic, and execution flow, please refer to the **[Technical Deep Dive](TECHNICAL_DEEP_DIVE.md)**.

## Installation

1. Ensure Python 3.7+ is installed
2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

```bash
python main.py <path_to_target_directory> [--output <output_directory>]
```

### Examples

```bash
# Scan current directory
python main.py .

# Scan specific project
python main.py C:\Projects\MyApp

# Specify custom output location
python main.py C:\Projects\MyApp --output C:\Reports
```

## Output

The tool generates an Excel file: `Application_Depth_Tracker_YYYYMMDD_HHMMSS.xlsx`

### Report Tabs

1. **Summary_Dashboard**: 
   - **Basic Metrics**: Total files, code lines, and size
   - **Complexity Metrics Summary**: Totals for all detected patterns (CSS, JS, AJAX, Dynamic code)
   - **Global Extension Breakdown**: File count by extension
2. **Directory_Analysis**: Statistics grouped by directory with depth information
3. **File_Details**: Basic file metadata (path, name, extension, lines, size)
4. **Complexity_Metrics**: Detailed per-file complexity analysis with full paths
5. **AJAX_Detailed_Report (NEW!)**: Granular audit of every AJAX construct:
   - **Code & Line Number**: Exact location of the call.
   - **Category**: Distinguishes **Logical Requests** (Network Traffic) from **Constructs** (Events, Configuration, Utilities).
   - **Capability Analysis**: (Telemetry vs Data vs Script Loading).
   - **Migration Difficulty**: (Easy/Medium/Hard).

### Summary Dashboard Highlights

The **Summary_Dashboard** tab provides an at-a-glance overview with totals for:

**CSS Patterns:**
- Inline CSS (style="...") 
- Internal Style Blocks (<style>)
- External Stylesheets (<link>)

**JavaScript Patterns:**
- Inline JS (event handlers)
- Internal Script Blocks (<script>)
- External Script Tags (src="...")

**AJAX & Network Calls (Semantic Counting):**
- **Total Logical Requests**: Counts actual network initiations (e.g., `fetch`, `$.ajax`, `xhr.send`, `PageMethods`, `UpdatePanel`).
  - *Note: Excludes Events (`ajaxStart`), Config (`ajaxSetup`), and Helpers (`serialize`) to avoid inflation.*
- **Files with AJAX**: Number of files containing any AJAX construct.

**Dynamic Code Generation:**
- Dynamic JS (eval, innerHTML, etc.)
- Dynamic CSS (style manipulation)

### Supported Frameworks & Patterns
The tool now supports **100% Definitive Detection** for:
- **Core JS**: `XMLHttpRequest` (including `abort`, `headers`), `Fetch API` (`Request`, `Headers`).
- **jQuery**: All methods (`$.ajax`, `$.get`...), Global Events, Configuration, Utilities.
- **ASP.NET (Legacy & Modern)**: `Sys.Net.WebRequest`, `PageMethods`, `__doPostBack`, `<asp:UpdatePanel>`, `[WebMethod]`.
- **Utilities**: `JSON.parse`, `JSON.stringify`.

## Detailed Documentation

We have created comprehensive guides to help you understand and remediate the detected patterns:

1.  **[AJAX Mastery Guide](AJAX_MASTERY_GUIDE.md)**: The textbook definition of AJAX, generations of coding patterns, and how to analyze them.
2.  **[Definitive AJAX Reference](AJAX_DEFINITIVE_REFERENCE.md)**: A finite, "countable" list of every way to make a network request in a browser (XHR, Fetch, Libraries).
3.  **[AJAX Capabilities & Use Cases](AJAX_CAPABILITIES_AND_USE_CASES.md)**: Identifying the *purpose* of a call (Data Exchange vs Script Loading vs Telemetry) and its Risk Profile.
4.  **[CSP Migration & AJAX Guide](CSP_MIGRATION_AND_AJAX.md)**: Strategies for implementing CSP, refactoring "Hard" patterns, and achieving "Zero-Miss" detection accuracy.

## Requirements

- Python 3.7+
- pandas >= 2.0.0
- openpyxl >= 3.1.0

## Performance

The tool uses multithreading (10 workers by default) to process files concurrently, making it suitable for large codebases.

### Excluded Folders

To maintain accuracy on source code while avoiding dependency bloat, the following folders are automatically excluded:

**Dependencies**: `node_modules`, `vendor`, `packages`  
**Version Control**: `.git`, `.svn`, `.hg`  
**Build Outputs**: `bin`, `obj`, `dist`, `build`, `out`, `target`  
**Virtual Environments**: `venv`, `env`, `.venv`, `__pycache__`, `.pytest_cache`

This ensures 100% accuracy on your source code while skipping thousands of third-party files.

## Known Limitations

To guarantee "Zero-Miss" accuracy, the detection engine is designed to be **Aggressive**.
*   It counts constructs within comments (`// fetch(url)`) or string literals (`var msg = "use $.ajax"`) as detections.
*   **Rationale**: We prioritize finding *every hidden call* over suppressing potential noise. A false positive is a nuisance; a false negative (missed call) is a migration risk.


